============================================
  SoryStream
  Moderní knihovna filmů, seriálů a anime
============================================

Motiv: černá + zelená + červená + modrá
Vzhled: boční menu, karty, moderní tmavý design

--------------------------------------------
INSTALACE (stačí jednou)
--------------------------------------------

1. Nainstaluj Python 3 (pokud ještě nemáš)
   https://www.python.org/downloads/
   (při instalaci zaškrtni "Add Python to PATH")

2. Otevři příkazový řádek / terminál a napiš:

   pip install customtkinter pillow

--------------------------------------------
SPUŠTĚNÍ
--------------------------------------------

1. Stáhni celou složku SoryStream
2. Otevři terminál v této složce a napiš:

   python sorystream.py

   (nebo:  python3 sorystream.py)

Při prvním spuštění se vytvoří soubor sorystream.db
– v něm se ukládají všechna tvoje data.

--------------------------------------------
CO APLIKACE UMÍ
--------------------------------------------

• Boční menu: Vše / Filmy / Seriály / Anime
• Přidávání, úprava a mazání položek
• Vyhledávání
• Filtrování podle stavu (Plánuji, Sleduji, Dokončeno, Odloženo)
• Hodnocení 0–10
• Poznámky
• Vše je v češtině
• Data zůstávají jen u tebe na disku

--------------------------------------------
STRUKTURA SOUBORŮ
--------------------------------------------

SoryStream/
├── sorystream.py      ← hlavní program (můžeš upravovat)
├── assets/            ← ikony a logo
│   ├── logo.png
│   ├── film.png
│   ├── serial.png
│   ├── anime.png
│   └── ...
├── sorystream.db      ← databáze (vytvoří se sama)
└── README.txt

--------------------------------------------
CHCEŠ NĚCO ZMĚNIT?
--------------------------------------------

Celý kód je v jednom souboru sorystream.py.
Můžeš ho otevřít v jakémkoliv editoru a upravovat.
Nebo mi napiš, co chceš přidat/upravit, a já ti to připravím.
