#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SoryStream – moderní knihovna filmů, seriálů a anime
Motiv: černá + zelená + červená + modrá
Technologie: Python 3 + CustomTkinter + SQLite
"""

import customtkinter as ctk
from tkinter import messagebox
import sqlite3
import os
from datetime import datetime
from PIL import Image

# ====================== NASTAVENÍ ======================
APP_NAME = "SoryStream"
DB_NAME = "sorystream.db"
WINDOW_SIZE = "1200x750"
ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

# Barvy motivu
COLOR_BG = "#0d0d0d"
COLOR_SIDEBAR = "#121212"
COLOR_CARD = "#1a1a1a"
COLOR_GREEN = "#00c853"
COLOR_RED = "#ff1744"
COLOR_BLUE = "#2979ff"
COLOR_TEXT = "#f0f0f0"
COLOR_MUTED = "#888888"
COLOR_HOVER = "#222222"

# Předpřipravené žánry
ZANRY = [
    "Akční", "Animovaný", "Dobrodružný", "Dokumentární", "Drama",
    "Fantasy", "Horor", "Komedie", "Krimi", "Mysteriózní",
    "Romantický", "Sci-Fi", "Thriller", "Válečný", "Western",
    "Rodinný", "Sportovní", "Hudební", "Životopisný", "Anime",
    "Isekai", "Shonen", "Shojo", "Seinen", "Slice of Life", "Jiné"
]

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


# ====================== DATABÁZE ======================
def get_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS polozky (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nazev TEXT NOT NULL,
            typ TEXT NOT NULL,
            rok INTEGER,
            zanr TEXT,
            stav TEXT DEFAULT 'Plánuji',
            hodnoceni REAL,
            poznamka TEXT,
            datum_pridani TEXT,
            epizody INTEGER,
            delka INTEGER,
            studio TEXT,
            jazyk TEXT,
            oblibene INTEGER DEFAULT 0
        )
    """)
    # Přidání nových sloupců, pokud databáze už existovala ze starší verze
    for sloupec, typ in [
        ("epizody", "INTEGER"),
        ("delka", "INTEGER"),
        ("studio", "TEXT"),
        ("jazyk", "TEXT"),
        ("oblibene", "INTEGER DEFAULT 0")
    ]:
        try:
            cur.execute(f"ALTER TABLE polozky ADD COLUMN {sloupec} {typ}")
        except sqlite3.OperationalError:
            pass  # sloupec už existuje
    conn.commit()
    return conn


# ====================== HLAVNÍ APLIKACE ======================
class SoryStream(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title(APP_NAME)
        self.geometry(WINDOW_SIZE)
        self.minsize(900, 600)
        self.configure(fg_color=COLOR_BG)

        try:
            self.iconphoto(False, ctk.CTkImage(Image.open(os.path.join(ASSETS, "logo.png")), size=(32, 32))._light_image)
        except Exception:
            pass

        self.conn = get_db()
        self.aktualni_filtr = "Vše"
        self.hledany_text = ""

        self._nacti_ikony()
        self._vytvor_ui()
        self.nacti_data()

    def _nacti_ikony(self):
        self.ikony = {}
        velikosti = {
            "logo": (48, 48),
            "film": (22, 22),
            "serial": (22, 22),
            "anime": (22, 22),
            "all": (22, 22),
            "add": (20, 20),
            "search": (18, 18),
        }
        for nazev, size in velikosti.items():
            cesta = os.path.join(ASSETS, f"{nazev}.png")
            if os.path.exists(cesta):
                img = Image.open(cesta)
                self.ikony[nazev] = ctk.CTkImage(light_image=img, dark_image=img, size=size)
            else:
                self.ikony[nazev] = None

    def _vytvor_ui(self):
        # ========== SIDEBAR ==========
        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color=COLOR_SIDEBAR)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_frame.pack(pady=(25, 30), padx=15)

        if self.ikony.get("logo"):
            ctk.CTkLabel(logo_frame, image=self.ikony["logo"], text="").pack(side="left", padx=(0, 10))
        ctk.CTkLabel(
            logo_frame, text="SoryStream",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color=COLOR_GREEN
        ).pack(side="left")

        self.nav_tlacitka = {}
        menu_polozky = [
            ("Vše", "all", COLOR_MUTED),
            ("Filmy", "film", COLOR_RED),
            ("Seriály", "serial", COLOR_GREEN),
            ("Anime", "anime", COLOR_BLUE),
        ]

        for text, ikona, barva in menu_polozky:
            btn = ctk.CTkButton(
                self.sidebar,
                text=f"  {text}",
                image=self.ikony.get(ikona),
                anchor="w",
                height=42,
                corner_radius=8,
                fg_color="transparent",
                hover_color=COLOR_HOVER,
                text_color=COLOR_TEXT,
                font=ctk.CTkFont(size=14),
                command=lambda t=text: self.zmen_filtr(t)
            )
            btn.pack(fill="x", padx=12, pady=3)
            self.nav_tlacitka[text] = btn

        ctk.CTkFrame(self.sidebar, height=1, fg_color="#333").pack(fill="x", padx=20, pady=20)

        ctk.CTkButton(
            self.sidebar,
            text="  Přidat položku",
            image=self.ikony.get("add"),
            anchor="w",
            height=42,
            corner_radius=8,
            fg_color=COLOR_GREEN,
            hover_color="#00a844",
            text_color="#000",
            font=ctk.CTkFont(size=14, weight="bold"),
            command=self.pridat_polozku
        ).pack(fill="x", padx=12, pady=5)

        ctk.CTkLabel(
            self.sidebar,
            text="v1.1  •  lokální data",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_MUTED
        ).pack(side="bottom", pady=15)

        # ========== HLAVNÍ OBLAST ==========
        self.main = ctk.CTkFrame(self, fg_color=COLOR_BG, corner_radius=0)
        self.main.pack(side="right", fill="both", expand=True)

        top = ctk.CTkFrame(self.main, fg_color="transparent", height=70)
        top.pack(fill="x", padx=25, pady=(20, 10))
        top.pack_propagate(False)

        self.nadpis = ctk.CTkLabel(
            top, text="Všechny položky",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=COLOR_TEXT
        )
        self.nadpis.pack(side="left")

        search_frame = ctk.CTkFrame(top, fg_color=COLOR_CARD, corner_radius=10, width=280)
        search_frame.pack(side="right")
        search_frame.pack_propagate(False)

        if self.ikony.get("search"):
            ctk.CTkLabel(search_frame, image=self.ikony["search"], text="").pack(side="left", padx=(12, 5))
        self.search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Hledat...",
            border_width=0,
            fg_color="transparent",
            text_color=COLOR_TEXT,
            font=ctk.CTkFont(size=13),
            width=220
        )
        self.search_entry.pack(side="left", fill="y", pady=8)
        self.search_entry.bind("<KeyRelease>", lambda e: self.hledat())

        stav_frame = ctk.CTkFrame(self.main, fg_color="transparent")
        stav_frame.pack(fill="x", padx=25, pady=(0, 10))

        ctk.CTkLabel(stav_frame, text="Stav:", text_color=COLOR_MUTED).pack(side="left", padx=(0, 8))
        self.stav_var = ctk.StringVar(value="Vše")
        for stav in ["Vše", "Plánuji", "Sleduji", "Dokončeno", "Odloženo"]:
            ctk.CTkRadioButton(
                stav_frame, text=stav, variable=self.stav_var, value=stav,
                command=self.nacti_data,
                fg_color=COLOR_GREEN, hover_color=COLOR_GREEN,
                text_color=COLOR_TEXT, font=ctk.CTkFont(size=12)
            ).pack(side="left", padx=6)

        self.scroll = ctk.CTkScrollableFrame(self.main, fg_color=COLOR_BG, corner_radius=0)
        self.scroll.pack(fill="both", expand=True, padx=20, pady=(5, 15))

        self.status = ctk.CTkLabel(
            self.main, text="Připraveno",
            font=ctk.CTkFont(size=11), text_color=COLOR_MUTED, anchor="w"
        )
        self.status.pack(fill="x", padx=25, pady=(0, 10))

        self.zmen_filtr("Vše")

    def zmen_filtr(self, filtr: str):
        self.aktualni_filtr = filtr
        mapping = {
            "Vše": "Všechny položky",
            "Filmy": "Filmy",
            "Seriály": "Seriály",
            "Anime": "Anime"
        }
        self.nadpis.configure(text=mapping.get(filtr, filtr))

        for nazev, btn in self.nav_tlacitka.items():
            if nazev == filtr:
                btn.configure(fg_color=COLOR_HOVER, text_color=COLOR_GREEN)
            else:
                btn.configure(fg_color="transparent", text_color=COLOR_TEXT)

        self.nacti_data()

    def hledat(self):
        self.hledany_text = self.search_entry.get().strip().lower()
        self.nacti_data()

    def nacti_data(self):
        for widget in self.scroll.winfo_children():
            widget.destroy()

        query = """
            SELECT id, nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
                   epizody, delka, studio, jazyk, oblibene
            FROM polozky WHERE 1=1
        """
        params = []

        if self.aktualni_filtr == "Filmy":
            query += " AND typ = 'Film'"
        elif self.aktualni_filtr == "Seriály":
            query += " AND typ = 'Seriál'"
        elif self.aktualni_filtr == "Anime":
            query += " AND typ = 'Anime'"

        stav = self.stav_var.get()
        if stav != "Vše":
            query += " AND stav = ?"
            params.append(stav)

        if self.hledany_text:
            query += " AND (LOWER(nazev) LIKE ? OR LOWER(zanr) LIKE ? OR LOWER(poznamka) LIKE ? OR LOWER(studio) LIKE ?)"
            params.extend([f"%{self.hledany_text}%"] * 4)

        query += " ORDER BY oblibene DESC, nazev COLLATE NOCASE"

        cur = self.conn.cursor()
        cur.execute(query, params)
        radky = cur.fetchall()

        if not radky:
            ctk.CTkLabel(
                self.scroll,
                text="Žádné položky\nKlikni na „Přidat položku“ v levém menu",
                font=ctk.CTkFont(size=15),
                text_color=COLOR_MUTED,
                justify="center"
            ).pack(pady=80)
        else:
            for radek in radky:
                self._vytvor_kartu(radek)

        self.status.configure(text=f"Zobrazeno položek: {len(radky)}")

    def _vytvor_kartu(self, radek):
        (id_, nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
         epizody, delka, studio, jazyk, oblibene) = radek

        if typ == "Film":
            accent = COLOR_RED
        elif typ == "Seriál":
            accent = COLOR_GREEN
        else:
            accent = COLOR_BLUE

        karta = ctk.CTkFrame(self.scroll, fg_color=COLOR_CARD, corner_radius=12, height=100)
        karta.pack(fill="x", pady=6, padx=5)
        karta.pack_propagate(False)

        ctk.CTkFrame(karta, width=5, fg_color=accent, corner_radius=0).pack(side="left", fill="y")

        obsah = ctk.CTkFrame(karta, fg_color="transparent")
        obsah.pack(side="left", fill="both", expand=True, padx=15, pady=10)

        horni = ctk.CTkFrame(obsah, fg_color="transparent")
        horni.pack(fill="x")

        nazev_text = f"{'★ ' if oblibene else ''}{nazev}"
        ctk.CTkLabel(
            horni, text=nazev_text,
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLOR_TEXT, anchor="w"
        ).pack(side="left")

        ctk.CTkLabel(
            horni, text=typ,
            font=ctk.CTkFont(size=11),
            text_color=accent,
            fg_color="#222", corner_radius=6, width=60, height=22
        ).pack(side="right", padx=(10, 0))

        info_text = []
        if rok:
            info_text.append(str(rok))
        if zanr:
            info_text.append(zanr)
        if stav:
            info_text.append(stav)
        if hodnoceni is not None:
            info_text.append(f"★ {hodnoceni:.1f}")
        if epizody:
            info_text.append(f"{epizody} ep.")
        if delka:
            info_text.append(f"{delka} min")
        if studio:
            info_text.append(studio)

        ctk.CTkLabel(
            obsah, text="  •  ".join(info_text),
            font=ctk.CTkFont(size=12),
            text_color=COLOR_MUTED, anchor="w"
        ).pack(fill="x", pady=(4, 0))

        btn_frame = ctk.CTkFrame(karta, fg_color="transparent", width=100)
        btn_frame.pack(side="right", padx=10)

        ctk.CTkButton(
            btn_frame, text="Upravit", width=70, height=28,
            corner_radius=6, fg_color="#333", hover_color="#444",
            font=ctk.CTkFont(size=12),
            command=lambda i=id_: self.upravit_polozku(i)
        ).pack(pady=3)

        ctk.CTkButton(
            btn_frame, text="Smazat", width=70, height=28,
            corner_radius=6, fg_color="#3a1515", hover_color=COLOR_RED,
            font=ctk.CTkFont(size=12),
            command=lambda i=id_, n=nazev: self.smazat_polozku(i, n)
        ).pack(pady=3)

    def pridat_polozku(self):
        dialog = PolozkaDialog(self, "Přidat novou položku")
        self.wait_window(dialog)
        if dialog.vysledek:
            d = dialog.vysledek
            cur = self.conn.cursor()
            cur.execute("""
                INSERT INTO polozky
                (nazev, typ, rok, zanr, stav, hodnoceni, poznamka, datum_pridani,
                 epizody, delka, studio, jazyk, oblibene)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                d["nazev"], d["typ"], d["rok"], d["zanr"], d["stav"],
                d["hodnoceni"], d["poznamka"],
                datetime.now().strftime("%Y-%m-%d %H:%M"),
                d["epizody"], d["delka"], d["studio"], d["jazyk"], d["oblibene"]
            ))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Přidáno: {d['nazev']}")

    def upravit_polozku(self, id_):
        cur = self.conn.cursor()
        cur.execute("""
            SELECT nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
                   epizody, delka, studio, jazyk, oblibene
            FROM polozky WHERE id=?
        """, (id_,))
        r = cur.fetchone()
        if not r:
            return
        data = {
            "nazev": r[0], "typ": r[1], "rok": r[2], "zanr": r[3],
            "stav": r[4], "hodnoceni": r[5], "poznamka": r[6],
            "epizody": r[7], "delka": r[8], "studio": r[9],
            "jazyk": r[10], "oblibene": r[11]
        }
        dialog = PolozkaDialog(self, "Upravit položku", data)
        self.wait_window(dialog)
        if dialog.vysledek:
            d = dialog.vysledek
            cur.execute("""
                UPDATE polozky SET
                    nazev=?, typ=?, rok=?, zanr=?, stav=?, hodnoceni=?, poznamka=?,
                    epizody=?, delka=?, studio=?, jazyk=?, oblibene=?
                WHERE id=?
            """, (
                d["nazev"], d["typ"], d["rok"], d["zanr"], d["stav"],
                d["hodnoceni"], d["poznamka"],
                d["epizody"], d["delka"], d["studio"], d["jazyk"], d["oblibene"],
                id_
            ))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Upraveno: {d['nazev']}")

    def smazat_polozku(self, id_, nazev):
        if messagebox.askyesno("Smazat", f"Opravdu smazat „{nazev}“?", parent=self):
            cur = self.conn.cursor()
            cur.execute("DELETE FROM polozky WHERE id=?", (id_,))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Smazáno: {nazev}")


# ====================== DIALOG ======================
class PolozkaDialog(ctk.CTkToplevel):
    def __init__(self, parent, titul, data=None):
        super().__init__(parent)
        self.title(titul)
        self.geometry("520x720")          # větší okno, aby bylo vše vidět
        self.minsize(480, 650)
        self.resizable(True, True)
        self.configure(fg_color=COLOR_BG)
        self.transient(parent)
        self.grab_set()
        self.vysledek = None

        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - 260
        y = parent.winfo_y() + 30
        self.geometry(f"+{x}+{y}")

        # Scrollovatelný obsah
        container = ctk.CTkScrollableFrame(self, fg_color=COLOR_CARD, corner_radius=12)
        container.pack(fill="both", expand=True, padx=15, pady=15)

        def label(text):
            ctk.CTkLabel(container, text=text, text_color=COLOR_MUTED).pack(anchor="w", padx=15, pady=(12, 2))

        # Název
        label("Název *")
        self.nazev = ctk.CTkEntry(container, height=36, corner_radius=8)
        self.nazev.pack(fill="x", padx=15)

        # Typ
        label("Typ *")
        self.typ = ctk.CTkOptionMenu(
            container, values=["Film", "Seriál", "Anime"],
            height=36, corner_radius=8,
            fg_color="#2a2a2a", button_color=COLOR_GREEN, button_hover_color="#00a844"
        )
        self.typ.pack(fill="x", padx=15)
        self.typ.set("Film")

        # Rok + Hodnocení
        radka1 = ctk.CTkFrame(container, fg_color="transparent")
        radka1.pack(fill="x", padx=15, pady=(12, 0))

        leva = ctk.CTkFrame(radka1, fg_color="transparent")
        leva.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkLabel(leva, text="Rok", text_color=COLOR_MUTED).pack(anchor="w")
        self.rok = ctk.CTkEntry(leva, height=36, corner_radius=8)
        self.rok.pack(fill="x")

        prava = ctk.CTkFrame(radka1, fg_color="transparent")
        prava.pack(side="left", fill="x", expand=True, padx=(8, 0))
        ctk.CTkLabel(prava, text="Hodnocení (0–10)", text_color=COLOR_MUTED).pack(anchor="w")
        self.hodnoceni = ctk.CTkEntry(prava, height=36, corner_radius=8)
        self.hodnoceni.pack(fill="x")

        # Žánr (rozbalovací)
        label("Žánr")
        self.zanr = ctk.CTkOptionMenu(
            container, values=ZANRY,
            height=36, corner_radius=8,
            fg_color="#2a2a2a", button_color=COLOR_GREEN, button_hover_color="#00a844"
        )
        self.zanr.pack(fill="x", padx=15)
        self.zanr.set("Jiné")

        # Stav
        label("Stav")
        self.stav = ctk.CTkOptionMenu(
            container, values=["Plánuji", "Sleduji", "Dokončeno", "Odloženo"],
            height=36, corner_radius=8,
            fg_color="#2a2a2a", button_color=COLOR_GREEN, button_hover_color="#00a844"
        )
        self.stav.pack(fill="x", padx=15)
        self.stav.set("Plánuji")

        # === NOVÁ POLE ===
        # Epizody + Délka
        radka2 = ctk.CTkFrame(container, fg_color="transparent")
        radka2.pack(fill="x", padx=15, pady=(12, 0))

        leva2 = ctk.CTkFrame(radka2, fg_color="transparent")
        leva2.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkLabel(leva2, text="Počet epizod", text_color=COLOR_MUTED).pack(anchor="w")
        self.epizody = ctk.CTkEntry(leva2, height=36, corner_radius=8, placeholder_text="např. 12")
        self.epizody.pack(fill="x")

        prava2 = ctk.CTkFrame(radka2, fg_color="transparent")
        prava2.pack(side="left", fill="x", expand=True, padx=(8, 0))
        ctk.CTkLabel(prava2, text="Délka (minuty)", text_color=COLOR_MUTED).pack(anchor="w")
        self.delka = ctk.CTkEntry(prava2, height=36, corner_radius=8, placeholder_text="např. 120")
        self.delka.pack(fill="x")

        # Studio
        label("Studio / Režisér")
        self.studio = ctk.CTkEntry(container, height=36, corner_radius=8, placeholder_text="např. Studio Ghibli, Nolan...")
        self.studio.pack(fill="x", padx=15)

        # Jazyk
        label("Jazyk")
        self.jazyk = ctk.CTkOptionMenu(
            container,
            values=["Čeština", "Angličtina", "Japonština", "Korejština", "Čínština",
                    "Němčina", "Francouzština", "Španělština", "Jiný", "Bez preference"],
            height=36, corner_radius=8,
            fg_color="#2a2a2a", button_color=COLOR_GREEN, button_hover_color="#00a844"
        )
        self.jazyk.pack(fill="x", padx=15)
        self.jazyk.set("Bez preference")

        # Oblíbené
        label("Oblíbené")
        self.oblibene_var = ctk.StringVar(value="Ne")
        self.oblibene = ctk.CTkOptionMenu(
            container, values=["Ne", "Ano"],
            variable=self.oblibene_var,
            height=36, corner_radius=8,
            fg_color="#2a2a2a", button_color=COLOR_GREEN, button_hover_color="#00a844"
        )
        self.oblibene.pack(fill="x", padx=15)

        # Poznámka
        label("Poznámka")
        self.poznamka = ctk.CTkTextbox(container, height=80, corner_radius=8)
        self.poznamka.pack(fill="x", padx=15)

        # Tlačítka (vždy viditelná dole)
        btn_frame = ctk.CTkFrame(self, fg_color=COLOR_BG)
        btn_frame.pack(fill="x", padx=15, pady=(0, 15))

        ctk.CTkButton(
            btn_frame, text="Uložit", width=140, height=40,
            corner_radius=8, fg_color=COLOR_GREEN, hover_color="#00a844",
            text_color="#000", font=ctk.CTkFont(size=14, weight="bold"),
            command=self.ulozit
        ).pack(side="left", padx=(20, 10))

        ctk.CTkButton(
            btn_frame, text="Zrušit", width=140, height=40,
            corner_radius=8, fg_color="#333", hover_color="#444",
            font=ctk.CTkFont(size=14),
            command=self.destroy
        ).pack(side="left")

        # Předvyplnění
        if data:
            self.nazev.insert(0, data.get("nazev") or "")
            self.typ.set(data.get("typ") or "Film")
            if data.get("rok"):
                self.rok.insert(0, str(data["rok"]))
            zanr_val = data.get("zanr") or "Jiné"
            if zanr_val in ZANRY:
                self.zanr.set(zanr_val)
            else:
                self.zanr.set("Jiné")
            self.stav.set(data.get("stav") or "Plánuji")
            if data.get("hodnoceni") is not None:
                self.hodnoceni.insert(0, str(data["hodnoceni"]))
            if data.get("epizody"):
                self.epizody.insert(0, str(data["epizody"]))
            if data.get("delka"):
                self.delka.insert(0, str(data["delka"]))
            self.studio.insert(0, data.get("studio") or "")
            self.jazyk.set(data.get("jazyk") or "Bez preference")
            self.oblibene_var.set("Ano" if data.get("oblibene") else "Ne")
            self.poznamka.insert("1.0", data.get("poznamka") or "")

        self.nazev.focus()

    def ulozit(self):
        nazev = self.nazev.get().strip()
        if not nazev:
            messagebox.showerror("Chyba", "Název je povinný!", parent=self)
            return

        rok = self.rok.get().strip()
        if rok:
            try:
                rok = int(rok)
                if not (1888 <= rok <= 2100):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Chyba", "Rok musí být číslo 1888–2100.", parent=self)
                return
        else:
            rok = None

        hod = self.hodnoceni.get().strip()
        if hod:
            try:
                hod = float(hod.replace(",", "."))
                if not (0 <= hod <= 10):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Chyba", "Hodnocení musí být 0–10.", parent=self)
                return
        else:
            hod = None

        epizody = self.epizody.get().strip()
        if epizody:
            try:
                epizody = int(epizody)
            except ValueError:
                messagebox.showerror("Chyba", "Počet epizod musí být číslo.", parent=self)
                return
        else:
            epizody = None

        delka = self.delka.get().strip()
        if delka:
            try:
                delka = int(delka)
            except ValueError:
                messagebox.showerror("Chyba", "Délka musí být číslo (minuty).", parent=self)
                return
        else:
            delka = None

        self.vysledek = {
            "nazev": nazev,
            "typ": self.typ.get(),
            "rok": rok,
            "zanr": self.zanr.get(),
            "stav": self.stav.get(),
            "hodnoceni": hod,
            "poznamka": self.poznamka.get("1.0", "end").strip() or None,
            "epizody": epizody,
            "delka": delka,
            "studio": self.studio.get().strip() or None,
            "jazyk": self.jazyk.get(),
            "oblibene": 1 if self.oblibene_var.get() == "Ano" else 0
        }
        self.destroy()


# ====================== SPUŠTĚNÍ ======================
if __name__ == "__main__":
    app = SoryStream()
    app.mainloop()
