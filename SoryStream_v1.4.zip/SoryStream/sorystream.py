#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SoryStream v1.4
Moderní knihovna + vestavěný přehrávač (mpv)
Motiv: černá + červená + zelená
"""

import customtkinter as ctk
from tkinter import messagebox, filedialog
import sqlite3
import os
import sys
from datetime import datetime
from PIL import Image

# Pokus o načtení mpv
try:
    import mpv
    MPV_AVAILABLE = True
except ImportError:
    MPV_AVAILABLE = False

# ====================== NASTAVENÍ ======================
APP_NAME = "SoryStream"
DB_NAME = "sorystream.db"
WINDOW_SIZE = "1280x800"
ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

COLOR_BG = "#0a0a0a"
COLOR_SIDEBAR = "#111111"
COLOR_CARD = "#161616"
COLOR_GREEN = "#00c853"
COLOR_GREEN_DARK = "#00a843"
COLOR_RED = "#ff1744"
COLOR_TEXT = "#f5f5f5"
COLOR_MUTED = "#888888"
COLOR_BORDER = "#2a2a2a"

ZANRY = [
    "Akční", "Animovaný", "Dobrodružný", "Dokumentární", "Drama",
    "Fantasy", "Horor", "Komedie", "Krimi", "Mysteriózní",
    "Romantický", "Sci-Fi", "Thriller", "Válečný", "Western",
    "Rodinný", "Sportovní", "Hudební", "Životopisný", "Anime",
    "Isekai", "Shonen", "Shojo", "Seinen", "Slice of Life", "Jiné"
]

VIDEO_EXTENSIONS = [
    ("Video soubory", "*.mp4 *.mkv *.avi *.mov *.wmv *.flv *.webm *.m4v *.mpg *.mpeg"),
    ("Všechny soubory", "*.*")
]

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


# ====================== DATABÁZE ======================
def get_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS polozky (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nazev TEXT NOT NULL,
            typ TEXT NOT NULL,
            rok INTEGER,
            zanr TEXT,
            stav TEXT DEFAULT 'Plánuji',
            hodnoceni REAL,
            poznamka TEXT,
            datum_pridani TEXT,
            epizody INTEGER,
            delka INTEGER,
            studio TEXT,
            jazyk TEXT,
            oblibene INTEGER DEFAULT 0,
            cesta_souboru TEXT
        )
    """)
    for col, typ in [
        ("epizody", "INTEGER"), ("delka", "INTEGER"), ("studio", "TEXT"),
        ("jazyk", "TEXT"), ("oblibene", "INTEGER DEFAULT 0"), ("cesta_souboru", "TEXT")
    ]:
        try:
            cur.execute(f"ALTER TABLE polozky ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError:
            pass
    conn.commit()
    return conn


# ====================== PŘEHRÁVAČ (mpv) ======================
class PrehravacWindow(ctk.CTkToplevel):
    def __init__(self, parent, zdroj, nazev="Přehrávání"):
        super().__init__(parent)
        self.title(f"SoryStream – {nazev}")
        self.geometry("1000x680")
        self.minsize(720, 480)
        self.configure(fg_color=COLOR_BG)
        self.protocol("WM_DELETE_WINDOW", self._zavrit)

        self.player = None
        self.zdroj = zdroj
        self.playing = False

        # Video oblast
        self.video_frame = ctk.CTkFrame(self, fg_color="#000000", corner_radius=0)
        self.video_frame.pack(fill="both", expand=True)

        # Ovládací panel
        controls = ctk.CTkFrame(self, fg_color=COLOR_SIDEBAR, height=72, corner_radius=0)
        controls.pack(fill="x", side="bottom")
        controls.pack_propagate(False)

        btn_frame = ctk.CTkFrame(controls, fg_color="transparent")
        btn_frame.pack(side="left", padx=20, pady=14)

        self.btn_play = ctk.CTkButton(
            btn_frame, text="▶", width=52, height=42, corner_radius=8,
            fg_color=COLOR_GREEN, hover_color=COLOR_GREEN_DARK, text_color="#000",
            font=ctk.CTkFont(size=18), command=self._toggle
        )
        self.btn_play.pack(side="left", padx=3)

        ctk.CTkButton(
            btn_frame, text="■", width=52, height=42, corner_radius=8,
            fg_color="#333", hover_color=COLOR_RED, font=ctk.CTkFont(size=16),
            command=self._stop
        ).pack(side="left", padx=3)

        # Volume
        vol_frame = ctk.CTkFrame(controls, fg_color="transparent")
        vol_frame.pack(side="right", padx=20, pady=14)
        ctk.CTkLabel(vol_frame, text="Hlasitost", text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(side="left", padx=(0, 8))
        self.volume = ctk.CTkSlider(
            vol_frame, from_=0, to=100, width=130,
            progress_color=COLOR_GREEN, button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.volume.set(70)
        self.volume.pack(side="left")
        self.volume.configure(command=self._set_volume)

        self.status_label = ctk.CTkLabel(
            controls, text=nazev, text_color=COLOR_TEXT, font=ctk.CTkFont(size=13)
        )
        self.status_label.pack(side="left", padx=20)

        self.after(300, self._spustit)

    def _spustit(self):
        if not MPV_AVAILABLE:
            messagebox.showerror(
                "mpv není k dispozici",
                "Pro vestavěný přehrávač nainstaluj:\n\n"
                "1. mpv (https://mpv.io/installation/)\n"
                "2. pip install python-mpv\n\n"
                "Zatím se otevře systémový přehrávač.",
                parent=self
            )
            self._system_open()
            self.destroy()
            return

        try:
            # Vytvoření mpv playeru připojeného k oknu
            self.player = mpv.MPV(
                wid=str(self.video_frame.winfo_id()),
                vo="gpu",
                hwdec="auto",
                keep_open="yes",
                osc="no",          # vypneme výchozí ovládání mpv
                input_default_bindings="no",
                input_vo_keyboard="no",
            )
            self.player.volume = 70
            self.player.play(self.zdroj)
            self.playing = True
            self.btn_play.configure(text="⏸")
            self.status_label.configure(text="Přehrávání…")
        except Exception as e:
            messagebox.showerror("Chyba mpv", str(e), parent=self)
            self._system_open()
            self.destroy()

    def _toggle(self):
        if not self.player:
            return
        if self.playing:
            self.player.pause = True
            self.playing = False
            self.btn_play.configure(text="▶")
            self.status_label.configure(text="Pozastaveno")
        else:
            self.player.pause = False
            self.playing = True
            self.btn_play.configure(text="⏸")
            self.status_label.configure(text="Přehrávání…")

    def _stop(self):
        if self.player:
            self.player.stop()
            self.playing = False
            self.btn_play.configure(text="▶")
            self.status_label.configure(text="Zastaveno")

    def _set_volume(self, val):
        if self.player:
            try:
                self.player.volume = float(val)
            except Exception:
                pass

    def _system_open(self):
        try:
            if sys.platform == "win32":
                os.startfile(self.zdroj)
            elif sys.platform == "darwin":
                import subprocess
                subprocess.call(["open", self.zdroj])
            else:
                import subprocess
                subprocess.call(["xdg-open", self.zdroj])
        except Exception:
            pass

    def _zavrit(self):
        if self.player:
            try:
                self.player.terminate()
            except Exception:
                pass
            self.player = None
        self.destroy()


# ====================== HLAVNÍ APLIKACE ======================
class SoryStream(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry(WINDOW_SIZE)
        self.minsize(1000, 650)
        self.configure(fg_color=COLOR_BG)

        try:
            self.iconphoto(False, ctk.CTkImage(
                Image.open(os.path.join(ASSETS, "logo.png")), size=(32, 32)
            )._light_image)
        except Exception:
            pass

        self.conn = get_db()
        self.aktualni_filtr = "Vše"
        self.hledany_text = ""

        self._nacti_ikony()
        self._vytvor_ui()
        self.nacti_data()

    def _nacti_ikony(self):
        self.ikony = {}
        for nazev, size in {
            "logo": (42, 42), "film": (20, 20), "serial": (20, 20),
            "anime": (20, 20), "all": (20, 20), "add": (18, 18), "search": (16, 16)
        }.items():
            cesta = os.path.join(ASSETS, f"{nazev}.png")
            if os.path.exists(cesta):
                img = Image.open(cesta)
                self.ikony[nazev] = ctk.CTkImage(light_image=img, dark_image=img, size=size)
            else:
                self.ikony[nazev] = None

    def _vytvor_ui(self):
        self.sidebar = ctk.CTkFrame(self, width=230, corner_radius=0, fg_color=COLOR_SIDEBAR)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_frame.pack(pady=(28, 35), padx=18)
        if self.ikony.get("logo"):
            ctk.CTkLabel(logo_frame, image=self.ikony["logo"], text="").pack(side="left", padx=(0, 10))
        ctk.CTkLabel(
            logo_frame, text="SoryStream",
            font=ctk.CTkFont(size=20, weight="bold"), text_color=COLOR_GREEN
        ).pack(side="left")

        self.nav_tlacitka = {}
        for text, ikona in [("Vše", "all"), ("Filmy", "film"), ("Seriály", "serial"), ("Anime", "anime")]:
            btn = ctk.CTkButton(
                self.sidebar, text=f"  {text}", image=self.ikony.get(ikona),
                anchor="w", height=44, corner_radius=10,
                fg_color="transparent", hover_color="#1a1a1a",
                text_color=COLOR_TEXT, font=ctk.CTkFont(size=14),
                command=lambda t=text: self.zmen_filtr(t)
            )
            btn.pack(fill="x", padx=14, pady=3)
            self.nav_tlacitka[text] = btn

        ctk.CTkFrame(self.sidebar, height=1, fg_color=COLOR_BORDER).pack(fill="x", padx=22, pady=22)

        ctk.CTkButton(
            self.sidebar, text="  Přidat položku", image=self.ikony.get("add"),
            anchor="w", height=44, corner_radius=10,
            fg_color=COLOR_GREEN, hover_color=COLOR_GREEN_DARK, text_color="#000",
            font=ctk.CTkFont(size=14, weight="bold"), command=self.pridat_polozku
        ).pack(fill="x", padx=14, pady=4)

        info = "v1.4  •  mpv přehrávač" if MPV_AVAILABLE else "v1.4  •  systémový přehrávač"
        ctk.CTkLabel(self.sidebar, text=info, font=ctk.CTkFont(size=11), text_color=COLOR_MUTED).pack(side="bottom", pady=16)

        self.main = ctk.CTkFrame(self, fg_color=COLOR_BG, corner_radius=0)
        self.main.pack(side="right", fill="both", expand=True)

        top = ctk.CTkFrame(self.main, fg_color="transparent", height=72)
        top.pack(fill="x", padx=28, pady=(22, 8))
        top.pack_propagate(False)

        self.nadpis = ctk.CTkLabel(
            top, text="Všechny položky",
            font=ctk.CTkFont(size=26, weight="bold"), text_color=COLOR_TEXT
        )
        self.nadpis.pack(side="left")

        search_frame = ctk.CTkFrame(top, fg_color=COLOR_CARD, corner_radius=12, width=300, height=42)
        search_frame.pack(side="right")
        search_frame.pack_propagate(False)
        if self.ikony.get("search"):
            ctk.CTkLabel(search_frame, image=self.ikony["search"], text="").pack(side="left", padx=(14, 6))
        self.search_entry = ctk.CTkEntry(
            search_frame, placeholder_text="Hledat film, seriál, anime...",
            border_width=0, fg_color="transparent", text_color=COLOR_TEXT,
            font=ctk.CTkFont(size=13), width=240
        )
        self.search_entry.pack(side="left", fill="y", pady=6)
        self.search_entry.bind("<KeyRelease>", lambda e: self.hledat())

        stav_frame = ctk.CTkFrame(self.main, fg_color="transparent")
        stav_frame.pack(fill="x", padx=28, pady=(0, 12))
        ctk.CTkLabel(stav_frame, text="Stav:", text_color=COLOR_MUTED, font=ctk.CTkFont(size=13)).pack(side="left", padx=(0, 10))
        self.stav_var = ctk.StringVar(value="Vše")
        for stav in ["Vše", "Plánuji", "Sleduji", "Dokončeno", "Odloženo"]:
            ctk.CTkRadioButton(
                stav_frame, text=stav, variable=self.stav_var, value=stav,
                command=self.nacti_data, fg_color=COLOR_GREEN, hover_color=COLOR_GREEN,
                text_color=COLOR_TEXT, font=ctk.CTkFont(size=12)
            ).pack(side="left", padx=7)

        self.scroll = ctk.CTkScrollableFrame(self.main, fg_color=COLOR_BG, corner_radius=0)
        self.scroll.pack(fill="both", expand=True, padx=22, pady=(0, 12))

        self.status = ctk.CTkLabel(
            self.main, text="Připraveno", font=ctk.CTkFont(size=11),
            text_color=COLOR_MUTED, anchor="w"
        )
        self.status.pack(fill="x", padx=28, pady=(0, 12))

        self.zmen_filtr("Vše")

    def zmen_filtr(self, filtr):
        self.aktualni_filtr = filtr
        mapping = {"Vše": "Všechny položky", "Filmy": "Filmy", "Seriály": "Seriály", "Anime": "Anime"}
        self.nadpis.configure(text=mapping.get(filtr, filtr))
        for nazev, btn in self.nav_tlacitka.items():
            if nazev == filtr:
                btn.configure(fg_color="#1a1a1a", text_color=COLOR_GREEN)
            else:
                btn.configure(fg_color="transparent", text_color=COLOR_TEXT)
        self.nacti_data()

    def hledat(self):
        self.hledany_text = self.search_entry.get().strip().lower()
        self.nacti_data()

    def nacti_data(self):
        for w in self.scroll.winfo_children():
            w.destroy()

        query = """
            SELECT id, nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
                   epizody, delka, studio, jazyk, oblibene, cesta_souboru
            FROM polozky WHERE 1=1
        """
        params = []
        if self.aktualni_filtr == "Filmy":
            query += " AND typ = 'Film'"
        elif self.aktualni_filtr == "Seriály":
            query += " AND typ = 'Seriál'"
        elif self.aktualni_filtr == "Anime":
            query += " AND typ = 'Anime'"

        if self.stav_var.get() != "Vše":
            query += " AND stav = ?"
            params.append(self.stav_var.get())

        if self.hledany_text:
            query += " AND (LOWER(nazev) LIKE ? OR LOWER(zanr) LIKE ? OR LOWER(poznamka) LIKE ? OR LOWER(studio) LIKE ?)"
            params.extend([f"%{self.hledany_text}%"] * 4)

        query += " ORDER BY oblibene DESC, nazev COLLATE NOCASE"
        cur = self.conn.cursor()
        cur.execute(query, params)
        radky = cur.fetchall()

        if not radky:
            ctk.CTkLabel(
                self.scroll, text="Žádné položky\n\nKlikni na „Přidat položku“ v levém menu",
                font=ctk.CTkFont(size=15), text_color=COLOR_MUTED, justify="center"
            ).pack(pady=100)
        else:
            for r in radky:
                self._vytvor_kartu(r)

        self.status.configure(text=f"Zobrazeno položek: {len(radky)}")

    def _vytvor_kartu(self, radek):
        (id_, nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
         epizody, delka, studio, jazyk, oblibene, cesta) = radek

        accent = COLOR_RED if typ == "Film" else COLOR_GREEN

        karta = ctk.CTkFrame(self.scroll, fg_color=COLOR_CARD, corner_radius=14, height=108)
        karta.pack(fill="x", pady=5, padx=4)
        karta.pack_propagate(False)

        ctk.CTkFrame(karta, width=5, fg_color=accent, corner_radius=0).pack(side="left", fill="y")

        obsah = ctk.CTkFrame(karta, fg_color="transparent")
        obsah.pack(side="left", fill="both", expand=True, padx=16, pady=12)

        horni = ctk.CTkFrame(obsah, fg_color="transparent")
        horni.pack(fill="x")
        ctk.CTkLabel(
            horni, text=f"{'★ ' if oblibene else ''}{nazev}",
            font=ctk.CTkFont(size=16, weight="bold"), text_color=COLOR_TEXT, anchor="w"
        ).pack(side="left")
        ctk.CTkLabel(
            horni, text=typ, font=ctk.CTkFont(size=11), text_color=accent,
            fg_color="#222", corner_radius=6, width=64, height=22
        ).pack(side="right")

        info = []
        if rok: info.append(str(rok))
        if zanr: info.append(zanr)
        if stav: info.append(stav)
        if hodnoceni is not None: info.append(f"★ {hodnoceni:.1f}")
        if epizody: info.append(f"{epizody} ep.")
        if delka: info.append(f"{delka} min")
        if studio: info.append(studio)
        if cesta:
            info.append("▶ Připraveno k přehrání")

        ctk.CTkLabel(
            obsah, text="  ·  ".join(info), font=ctk.CTkFont(size=12),
            text_color=COLOR_MUTED, anchor="w"
        ).pack(fill="x", pady=(5, 0))

        btns = ctk.CTkFrame(karta, fg_color="transparent", width=120)
        btns.pack(side="right", padx=12)

        if cesta:
            ctk.CTkButton(
                btns, text="▶ Přehrát", width=100, height=30, corner_radius=8,
                fg_color=COLOR_GREEN, hover_color=COLOR_GREEN_DARK, text_color="#000",
                font=ctk.CTkFont(size=12, weight="bold"),
                command=lambda p=cesta, n=nazev: self._prehrat(p, n)
            ).pack(pady=2)

        ctk.CTkButton(
            btns, text="Upravit", width=100, height=28, corner_radius=8,
            fg_color="#2a2a2a", hover_color="#333", font=ctk.CTkFont(size=12),
            command=lambda i=id_: self.upravit_polozku(i)
        ).pack(pady=2)

        ctk.CTkButton(
            btns, text="Smazat", width=100, height=28, corner_radius=8,
            fg_color="#2a1515", hover_color=COLOR_RED, font=ctk.CTkFont(size=12),
            command=lambda i=id_, n=nazev: self.smazat_polozku(i, n)
        ).pack(pady=2)

    def _prehrat(self, zdroj, nazev):
        if not zdroj.startswith("http") and not os.path.isfile(zdroj):
            messagebox.showerror("Chyba", "Soubor neexistuje:\n" + zdroj, parent=self)
            return
        PrehravacWindow(self, zdroj, nazev)

    def pridat_polozku(self):
        dialog = PolozkaDialog(self, "Přidat novou položku")
        self.wait_window(dialog)
        if dialog.vysledek:
            d = dialog.vysledek
            cur = self.conn.cursor()
            cur.execute("""
                INSERT INTO polozky
                (nazev, typ, rok, zanr, stav, hodnoceni, poznamka, datum_pridani,
                 epizody, delka, studio, jazyk, oblibene, cesta_souboru)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                d["nazev"], d["typ"], d["rok"], d["zanr"], d["stav"], d["hodnoceni"],
                d["poznamka"], datetime.now().strftime("%Y-%m-%d %H:%M"),
                d["epizody"], d["delka"], d["studio"], d["jazyk"], d["oblibene"], d["cesta_souboru"]
            ))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Přidáno: {d['nazev']}")

    def upravit_polozku(self, id_):
        cur = self.conn.cursor()
        cur.execute("""
            SELECT nazev, typ, rok, zanr, stav, hodnoceni, poznamka,
                   epizody, delka, studio, jazyk, oblibene, cesta_souboru
            FROM polozky WHERE id=?
        """, (id_,))
        r = cur.fetchone()
        if not r:
            return
        data = dict(zip(
            ["nazev", "typ", "rok", "zanr", "stav", "hodnoceni", "poznamka",
             "epizody", "delka", "studio", "jazyk", "oblibene", "cesta_souboru"], r
        ))
        dialog = PolozkaDialog(self, "Upravit položku", data)
        self.wait_window(dialog)
        if dialog.vysledek:
            d = dialog.vysledek
            cur.execute("""
                UPDATE polozky SET
                    nazev=?, typ=?, rok=?, zanr=?, stav=?, hodnoceni=?, poznamka=?,
                    epizody=?, delka=?, studio=?, jazyk=?, oblibene=?, cesta_souboru=?
                WHERE id=?
            """, (
                d["nazev"], d["typ"], d["rok"], d["zanr"], d["stav"], d["hodnoceni"],
                d["poznamka"], d["epizody"], d["delka"], d["studio"], d["jazyk"],
                d["oblibene"], d["cesta_souboru"], id_
            ))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Upraveno: {d['nazev']}")

    def smazat_polozku(self, id_, nazev):
        if messagebox.askyesno("Smazat", f"Opravdu smazat „{nazev}“?", parent=self):
            cur = self.conn.cursor()
            cur.execute("DELETE FROM polozky WHERE id=?", (id_,))
            self.conn.commit()
            self.nacti_data()
            self.status.configure(text=f"Smazáno: {nazev}")


# ====================== DIALOG ======================
class PolozkaDialog(ctk.CTkToplevel):
    def __init__(self, parent, titul, data=None):
        super().__init__(parent)
        self.title(titul)
        self.geometry("560x820")
        self.minsize(520, 720)
        self.configure(fg_color=COLOR_BG)
        self.transient(parent)
        self.grab_set()
        self.vysledek = None
        self.cesta_souboru = (data or {}).get("cesta_souboru")

        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - 280
        y = max(20, parent.winfo_y() + 15)
        self.geometry(f"+{x}+{y}")

        container = ctk.CTkScrollableFrame(self, fg_color=COLOR_CARD, corner_radius=14)
        container.pack(fill="both", expand=True, padx=16, pady=(16, 6))

        def lab(t):
            ctk.CTkLabel(container, text=t, text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w", padx=16, pady=(14, 3))

        lab("Název *")
        self.nazev = ctk.CTkEntry(container, height=38, corner_radius=8, border_color=COLOR_BORDER)
        self.nazev.pack(fill="x", padx=16)

        lab("Typ *")
        self.typ = ctk.CTkOptionMenu(
            container, values=["Film", "Seriál", "Anime"], height=38, corner_radius=8,
            fg_color="#222", button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.typ.pack(fill="x", padx=16)
        self.typ.set("Film")

        row1 = ctk.CTkFrame(container, fg_color="transparent")
        row1.pack(fill="x", padx=16, pady=(12, 0))
        l1 = ctk.CTkFrame(row1, fg_color="transparent")
        l1.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkLabel(l1, text="Rok", text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w")
        self.rok = ctk.CTkEntry(l1, height=38, corner_radius=8)
        self.rok.pack(fill="x")
        r1 = ctk.CTkFrame(row1, fg_color="transparent")
        r1.pack(side="left", fill="x", expand=True, padx=(8, 0))
        ctk.CTkLabel(r1, text="Hodnocení (0–10)", text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w")
        self.hodnoceni = ctk.CTkEntry(r1, height=38, corner_radius=8)
        self.hodnoceni.pack(fill="x")

        lab("Žánr")
        self.zanr = ctk.CTkOptionMenu(
            container, values=ZANRY, height=38, corner_radius=8,
            fg_color="#222", button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.zanr.pack(fill="x", padx=16)
        self.zanr.set("Jiné")

        lab("Stav")
        self.stav = ctk.CTkOptionMenu(
            container, values=["Plánuji", "Sleduji", "Dokončeno", "Odloženo"], height=38, corner_radius=8,
            fg_color="#222", button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.stav.pack(fill="x", padx=16)
        self.stav.set("Plánuji")

        row2 = ctk.CTkFrame(container, fg_color="transparent")
        row2.pack(fill="x", padx=16, pady=(12, 0))
        l2 = ctk.CTkFrame(row2, fg_color="transparent")
        l2.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkLabel(l2, text="Počet epizod", text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w")
        self.epizody = ctk.CTkEntry(l2, height=38, corner_radius=8, placeholder_text="např. 12")
        self.epizody.pack(fill="x")
        r2 = ctk.CTkFrame(row2, fg_color="transparent")
        r2.pack(side="left", fill="x", expand=True, padx=(8, 0))
        ctk.CTkLabel(r2, text="Délka (min)", text_color=COLOR_MUTED, font=ctk.CTkFont(size=12)).pack(anchor="w")
        self.delka = ctk.CTkEntry(r2, height=38, corner_radius=8, placeholder_text="např. 120")
        self.delka.pack(fill="x")

        lab("Studio / Režisér")
        self.studio = ctk.CTkEntry(container, height=38, corner_radius=8)
        self.studio.pack(fill="x", padx=16)

        lab("Jazyk")
        self.jazyk = ctk.CTkOptionMenu(
            container,
            values=["Čeština", "Angličtina", "Japonština", "Korejština", "Čínština",
                    "Němčina", "Francouzština", "Španělština", "Jiný", "Bez preference"],
            height=38, corner_radius=8,
            fg_color="#222", button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.jazyk.pack(fill="x", padx=16)
        self.jazyk.set("Bez preference")

        lab("Oblíbené")
        self.oblibene_var = ctk.StringVar(value="Ne")
        self.oblibene = ctk.CTkOptionMenu(
            container, values=["Ne", "Ano"], variable=self.oblibene_var, height=38, corner_radius=8,
            fg_color="#222", button_color=COLOR_GREEN, button_hover_color=COLOR_GREEN_DARK
        )
        self.oblibene.pack(fill="x", padx=16)

        lab("Zdroj videa (soubor nebo odkaz)")
        src_frame = ctk.CTkFrame(container, fg_color="transparent")
        src_frame.pack(fill="x", padx=16)

        self.cesta_entry = ctk.CTkEntry(
            src_frame, height=38, corner_radius=8,
            placeholder_text="Cesta k souboru nebo https://... odkaz"
        )
        self.cesta_entry.pack(side="left", fill="x", expand=True)
        if self.cesta_souboru:
            self.cesta_entry.insert(0, self.cesta_souboru)

        ctk.CTkButton(
            src_frame, text="Soubor", width=90, height=38, corner_radius=8,
            fg_color="#2a2a2a", hover_color="#333", command=self.vybrat_soubor
        ).pack(side="right", padx=(8, 0))

        lab("Poznámka")
        self.poznamka = ctk.CTkTextbox(container, height=70, corner_radius=8)
        self.poznamka.pack(fill="x", padx=16)

        btn_frame = ctk.CTkFrame(self, fg_color=COLOR_BG)
        btn_frame.pack(fill="x", padx=16, pady=14)

        ctk.CTkButton(
            btn_frame, text="Uložit", width=150, height=42, corner_radius=10,
            fg_color=COLOR_GREEN, hover_color=COLOR_GREEN_DARK, text_color="#000",
            font=ctk.CTkFont(size=14, weight="bold"), command=self.ulozit
        ).pack(side="left", padx=(20, 10))

        ctk.CTkButton(
            btn_frame, text="Zrušit", width=150, height=42, corner_radius=10,
            fg_color="#2a2a2a", hover_color="#333", font=ctk.CTkFont(size=14),
            command=self.destroy
        ).pack(side="left")

        if data:
            self.nazev.insert(0, data.get("nazev") or "")
            self.typ.set(data.get("typ") or "Film")
            if data.get("rok"):
                self.rok.insert(0, str(data["rok"]))
            z = data.get("zanr") or "Jiné"
            self.zanr.set(z if z in ZANRY else "Jiné")
            self.stav.set(data.get("stav") or "Plánuji")
            if data.get("hodnoceni") is not None:
                self.hodnoceni.insert(0, str(data["hodnoceni"]))
            if data.get("epizody"):
                self.epizody.insert(0, str(data["epizody"]))
            if data.get("delka"):
                self.delka.insert(0, str(data["delka"]))
            self.studio.insert(0, data.get("studio") or "")
            self.jazyk.set(data.get("jazyk") or "Bez preference")
            self.oblibene_var.set("Ano" if data.get("oblibene") else "Ne")
            self.poznamka.insert("1.0", data.get("poznamka") or "")

        self.nazev.focus()

    def vybrat_soubor(self):
        cesta = filedialog.askopenfilename(title="Vyber video", filetypes=VIDEO_EXTENSIONS, parent=self)
        if cesta:
            self.cesta_entry.delete(0, "end")
            self.cesta_entry.insert(0, cesta)

    def ulozit(self):
        nazev = self.nazev.get().strip()
        if not nazev:
            messagebox.showerror("Chyba", "Název je povinný!", parent=self)
            return

        def parse_int(val, name):
            val = val.strip()
            if not val:
                return None
            try:
                return int(val)
            except ValueError:
                messagebox.showerror("Chyba", f"{name} musí být číslo.", parent=self)
                return "ERR"

        rok = parse_int(self.rok.get(), "Rok")
        if rok == "ERR":
            return
        if rok and not (1888 <= rok <= 2100):
            messagebox.showerror("Chyba", "Rok musí být 1888–2100.", parent=self)
            return

        hod = self.hodnoceni.get().strip()
        if hod:
            try:
                hod = float(hod.replace(",", "."))
                if not (0 <= hod <= 10):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Chyba", "Hodnocení musí být 0–10.", parent=self)
                return
        else:
            hod = None

        epizody = parse_int(self.epizody.get(), "Epizody")
        if epizody == "ERR":
            return
        delka = parse_int(self.delka.get(), "Délka")
        if delka == "ERR":
            return

        cesta = self.cesta_entry.get().strip() or None

        self.vysledek = {
            "nazev": nazev,
            "typ": self.typ.get(),
            "rok": rok,
            "zanr": self.zanr.get(),
            "stav": self.stav.get(),
            "hodnoceni": hod,
            "poznamka": self.poznamka.get("1.0", "end").strip() or None,
            "epizody": epizody,
            "delka": delka,
            "studio": self.studio.get().strip() or None,
            "jazyk": self.jazyk.get(),
            "oblibene": 1 if self.oblibene_var.get() == "Ano" else 0,
            "cesta_souboru": cesta
        }
        self.destroy()


# ====================== SPUŠTĚNÍ ======================
if __name__ == "__main__":
    app = SoryStream()
    app.mainloop()
